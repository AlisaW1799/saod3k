﻿// ЭЛЯ АВДЕЕВА

#include <iostream>
#include "utils.h"
using namespace std;

// были перенесены в utils.cpp
//// 1)
////void Swap(int a, int b) {
////    int a = 3, b = 5;
////    int p = a;
////    a = b;
////    b = p;
////    cout << a << ' ' << b << endl;
////}
//
//// 2)
////void Swap(int* pa, int* pb) {
////    int z = *pa;
////    *pa = *pb;
////    *pb = z;
////}
//
//// 3)
//void Swap(int &pa, int &pb) {
//    int z = pa;
//    pa = pb;
//    pb = z;
//}

int main()
{
    // 1)
    //int x = 3;
    //int* p = &x;
    //cout << x << ' ' << *p << ' ' << p << endl;
    //p++;
    //cout << p << endl;
    //cout << p - &x << endl;

    //typedef unsigned char byte; // Нет встроенного byte

    //byte* pb = (byte*)--p;  // вернули указатель на x и преобразовали
    //for (byte* pt = pb; pt - pb < sizeof(int); pt++)
    //    cout << (int)*pt << ' ';    // выводим как int
    //cout << endl;

    int a = 3, b = 5;
    cout << a << " " << b << endl;

    // 2)
    /*Swap(&a, &b);
    cout << a << " " << b << endl;*/

    // 3)
    Swap(a, b);
    cout << a << " " << b << endl;
}
