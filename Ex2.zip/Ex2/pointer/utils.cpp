// 1)
//void Swap(int a, int b) {
//    int a = 3, b = 5;
//    int p = a;
//    a = b;
//    b = p;
//    cout << a << ' ' << b << endl;
//}

// 2)
//void Swap(int* pa, int* pb) {
//    int z = *pa;
//    *pa = *pb;
//    *pb = z;
//}

// 3)
void Swap(int& pa, int& pb) {
    int z = pa;
    pa = pb;
    pb = z;
}